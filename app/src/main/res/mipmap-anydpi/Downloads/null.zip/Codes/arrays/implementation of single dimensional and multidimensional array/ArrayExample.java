import java.util.Scanner;

public class ArrayExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Single-dimensional array
        System.out.println("Enter the size of the single-dimensional array:");
        int size = scanner.nextInt();
        int[] singleArray = new int[size];
        
        System.out.println("Enter " + size + " elements for the single-dimensional array:");
        for (int i = 0; i < size; i++) {
            singleArray[i] = scanner.nextInt();
        }
        
        System.out.println("Single-dimensional array elements:");
        for (int i = 0; i < size; i++) {
            System.out.print(singleArray[i] + " ");
        }
        System.out.println();
        
        // Multi-dimensional array
        System.out.println("Enter the number of rows for the multi-dimensional array:");
        int rows = scanner.nextInt();
        System.out.println("Enter the number of columns for the multi-dimensional array:");
        int columns = scanner.nextInt();
        int[][] multiArray = new int[rows][columns];
        
        System.out.println("Enter " + (rows * columns) + " elements for the multi-dimensional array:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                multiArray[i][j] = scanner.nextInt();
            }
        }
        
        System.out.println("Multi-dimensional array elements:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print(multiArray[i][j] + " ");
            }
            System.out.println();
        }
        
        scanner.close();
    }
}
