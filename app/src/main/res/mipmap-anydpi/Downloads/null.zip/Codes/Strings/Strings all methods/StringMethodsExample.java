public class StringMethodsExample {
    public static void main(String[] args) {
        // Creating a string
        String str = "Hello, World!";
        
        // Length method - returns the length of the string
        int length = str.length();
        System.out.println("Length of the string: " + length);
        
        // charAt method - returns the character at the specified index
        char characterAtIndex = str.charAt(7);
        System.out.println("Character at index 7: " + characterAtIndex);
        
        // substring method - returns a substring of the original string
        String substring = str.substring(7);
        System.out.println("Substring from index 7 onwards: " + substring);
        
        // contains method - checks if a string contains a specified sequence of characters
        boolean contains = str.contains("World");
        System.out.println("Does the string contain 'World'?: " + contains);
        
        // indexOf method - returns the index within the string of the first occurrence of a specified substring
        int indexOf = str.indexOf("World");
        System.out.println("Index of 'World': " + indexOf);
        
        // toUpperCase method - returns a string in uppercase
        String upperCase = str.toUpperCase();
        System.out.println("Uppercase string: " + upperCase);
        
        // toLowerCase method - returns a string in lowercase
        String lowerCase = str.toLowerCase();
        System.out.println("Lowercase string: " + lowerCase);
        
        // replace method - replaces occurrences of a specified substring with another substring
        String replacedString = str.replace("World", "Universe");
        System.out.println("String after replacement: " + replacedString);
        
        // trim method - removes leading and trailing whitespaces
        String stringWithWhitespaces = "   Hello, World!   ";
        String trimmedString = stringWithWhitespaces.trim();
        System.out.println("Trimmed string: '" + trimmedString + "'");
        
        // split method - splits a string into an array of substrings based on a delimiter
        String sentence = "Hello, how are you?";
        String[] words = sentence.split(" ");
        System.out.println("Words in the sentence:");
        for (String word : words) {
            System.out.println(word);
        }
    }
}

